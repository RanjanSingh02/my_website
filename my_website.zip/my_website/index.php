<?php include 'includes/header.php'; ?>
<div class="container">
  <h1>Hi! I’m</h1>
  <h1>Ranjan Kumar Singh</h1>
  <h1>Software Developer!</h1>
  <p>Hi, this is Ranjan Kumar. I am a Computer Science graduate in Software Development. My specialization area is web & software development, Digital marketing (On/Off-page SEO, social media marketing, email marketing). I assure you that I'll provide the best service in a time and efficient way. So, consider me for your job and I will give you my best.</p>
  <p>Passionate about Web Development Goal is to achieve a Good Position by doing satisfying work in the IT Field, strongly focused to complete the tasks in Fast-Faced Environment.</p>
  <h2>Thanks</h2>
</div>
<?php include 'includes/footer.php'; ?>
