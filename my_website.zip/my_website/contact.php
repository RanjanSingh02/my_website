<?php include 'includes/header.php'; ?>
<div class="container">
  <h1>Contact Us</h1>
  <form action="submit_form.php" method="post">
    <input type="text" name="name" placeholder="Your Name" required>
    <input type="email" name="email" placeholder="Your Email" required>
    <textarea name="message" placeholder="Your Message" required></textarea>
    <input type="submit" value="Send">
  </form>
</div>
<?php include 'includes/footer.php'; ?>
