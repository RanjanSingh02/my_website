<!-- header.php -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ranjan Kumar</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </nav>
  </header>

<!-- footer.php -->
  <footer>
    <a href="ranjankumar02feb@gmail.com">ranjankumar02feb@gmail.com</a>
    <p>&copy; Ranjan Kumar 2024</p>
  </footer>
  <script src="assets/js/script.js"></script>
</body>
</html>
